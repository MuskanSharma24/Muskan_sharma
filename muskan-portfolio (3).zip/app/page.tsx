import { Github, Linkedin, Mail, Phone, MapPin, ExternalLink, Calendar, Award, Code, Brain, Cloud } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function Portfolio() {
  const skills = {
    languages: ["Python", "JavaScript"],
    frameworks: ["Flask", "React", "Node.js"],
    aiml: ["LLaMA 3", "OpenAI GPT API", "Scikit-learn", "Random Forest"],
    cloud: ["Azure AI", "LangGraph", "Copilot Studio", "Cloud Computing"],
    databases: ["MongoDB", "PostgreSQL", "SQLite", "MySQL"],
    tools: ["Git", "REST API"],
  }

  const experiences = [
    {
      title: "Software Engineer",
      company: "SpeedTech.ai",
      location: "Pune, India",
      period: "May 2025 – Present",
      highlights: [
        "Spearheading development of AI-powered recruitment system for automated candidate evaluation",
        "Utilized Azure services and integrated multiple LLMs for job-candidate compatibility analysis",
        "Engineered backend architecture using PHP and Python with scalable API integrations",
        "Developed interactive frontend modules using JavaScript for recruiter dashboards",
        "Designed MySQL database schema for optimized candidate data storage and retrieval",
      ],
    },
    {
      title: "AI Engineer",
      company: "PWC",
      location: "India",
      period: "June 2024 - March 2025",
      highlights: [
        "Trained Llama 3 and Mistral models for the firm's framework",
        "Developed Pension Bot for Bhopal Government using Azure LLM with vector database",
        "Created Cybersecure solutions for threat identification in prompts, codes and commands",
        "Achieved 15% system boost by fine-tuning Gemini model for Cybersecure system",
        "Developed backend for data analysis tool using Azure API and LangGraph with GPT-4.0",
      ],
    },
    {
      title: "Data Analyst Intern",
      company: "Ways Ahead Global",
      location: "Remote",
      period: "May 2023 - September 2023",
      highlights: [
        "Achieved 10% growth for startups using analytical and logical thinking skills",
        "Led team in gathering investment data for startups",
        "Developed algorithm for company classification based on ROIs using clustering and deep learning",
      ],
    },
  ]

  const projects = [
    {
      title: "Budget Buddy",
      description: "AI-powered expense tracking application with ML-based spending predictions",
      tech: ["Python", "Flask", "React", "MongoDB", "Scikit-learn", "Random Forest"],
      features: ["Real-time expense categorization", "Smart budget recommendations", "Visual analytics dashboards"],
    },
    {
      title: "CoinPledge",
      description: "Web3-based crowdfunding platform using blockchain technology",
      tech: ["Ethereum", "React", "Node.js", "Web3.js"],
      features: ["Smart contract-based trust model", "Decentralized funding", "Automatic pledge execution"],
    },
    {
      title: "DataX",
      description: "AI-powered data analysis tool with natural language query processing",
      tech: ["PostgreSQL", "Azure", "OpenAI GPT API", "Python", "Pandas"],
      features: ["Dynamic SQL query generation", "AI-driven insights", "Automated visualizations"],
    },
    {
      title: "Sage Matrimony",
      description: "Full-stack matrimony platform for personalized matchmaking",
      tech: ["HTML", "CSS", "JavaScript", "Python", "SQLite"],
      features: ["User authentication", "Preference-based matching", "Payment gateway integration"],
    },
  ]

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-black/80 backdrop-blur-sm border-b border-gray-800 z-50">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-xl font-bold">MUSKAN SHARMA</h1>
            <div className="flex gap-6">
              <a href="#about" className="hover:text-gray-300 transition-colors">
                About
              </a>
              <a href="#experience" className="hover:text-gray-300 transition-colors">
                Experience
              </a>
              <a href="#projects" className="hover:text-gray-300 transition-colors">
                Projects
              </a>
              <a href="#contact" className="hover:text-gray-300 transition-colors">
                Contact
              </a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl lg:text-7xl font-light mb-6">
                AI ENGINEER &<br />
                <span className="italic">FULL-STACK</span>
                <br />
                DEVELOPER
              </h1>
              <p className="text-xl text-gray-400 mb-8 leading-relaxed">
                Computer Science undergraduate with robust experience in AI, Machine Learning, and Full-Stack
                Development. Building intelligent systems with cutting-edge technologies.
              </p>
              <div className="flex gap-4">
                <Button variant="outline" className="bg-white text-black hover:bg-gray-200">
                  <Mail className="w-4 h-4 mr-2" />
                  Get In Touch
                </Button>
                <Button variant="outline" className="bg-black text-white border-gray-600 hover:bg-gray-900">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  View Resume
                </Button>
              </div>
            </div>
            <div className="relative">
              <div className="w-80 h-80 mx-auto relative">
                <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-blue-500/20 rounded-full blur-3xl"></div>
                <div className="relative w-full h-full bg-gray-900 rounded-full border border-gray-700 flex items-center justify-center">
                  <Brain className="w-24 h-24 text-purple-400" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-6 bg-gray-950">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-light mb-12">ABOUT & SKILLS</h2>
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <p className="text-gray-300 text-lg leading-relaxed mb-8">
                Currently working as a Software Engineer at SpeedTech.ai, specializing in AI-powered recruitment
                systems. Previously served as an AI Engineer at PWC, where I trained advanced language models and
                developed cybersecurity solutions.
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-purple-400" />
                  <span>India</span>
                </div>
                <div className="flex items-center gap-3">
                  <Calendar className="w-5 h-5 text-purple-400" />
                  <span>Expected Graduation: 2025</span>
                </div>
                <div className="flex items-center gap-3">
                  <Award className="w-5 h-5 text-purple-400" />
                  <span>Vice-Chair IEEE WIE, Co-President GeeksforGeeks CU</span>
                </div>
              </div>
            </div>
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <Code className="w-5 h-5 text-blue-400" />
                  Languages & Frameworks
                </h3>
                <div className="flex flex-wrap gap-2">
                  {[...skills.languages, ...skills.frameworks].map((skill) => (
                    <Badge key={skill} variant="secondary" className="bg-gray-800 text-gray-300">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <Brain className="w-5 h-5 text-purple-400" />
                  AI/ML Technologies
                </h3>
                <div className="flex flex-wrap gap-2">
                  {skills.aiml.map((skill) => (
                    <Badge key={skill} variant="secondary" className="bg-gray-800 text-gray-300">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <Cloud className="w-5 h-5 text-green-400" />
                  Cloud & Databases
                </h3>
                <div className="flex flex-wrap gap-2">
                  {[...skills.cloud, ...skills.databases].map((skill) => (
                    <Badge key={skill} variant="secondary" className="bg-gray-800 text-gray-300">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-light mb-12">EXPERIENCE</h2>
          <div className="space-y-8">
            {experiences.map((exp, index) => (
              <Card key={index} className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl text-white">{exp.title}</CardTitle>
                      <CardDescription className="text-purple-400 text-lg">
                        {exp.company} • {exp.location}
                      </CardDescription>
                    </div>
                    <Badge variant="outline" className="border-gray-600 text-gray-300">
                      {exp.period}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {exp.highlights.map((highlight, idx) => (
                      <li key={idx} className="text-gray-300 flex items-start gap-2">
                        <span className="text-purple-400 mt-2">•</span>
                        <span>{highlight}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 px-6 bg-gray-950">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-light mb-12">FEATURED PROJECTS</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {projects.map((project, index) => (
              <Card key={index} className="bg-gray-900 border-gray-800 hover:border-gray-700 transition-colors">
                <CardHeader>
                  <CardTitle className="text-xl text-white">{project.title}</CardTitle>
                  <CardDescription className="text-gray-300">{project.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex flex-wrap gap-2">
                    {project.tech.map((tech) => (
                      <Badge key={tech} variant="secondary" className="bg-gray-800 text-gray-300 text-xs">
                        {tech}
                      </Badge>
                    ))}
                  </div>
                  <ul className="space-y-1">
                    {project.features.map((feature, idx) => (
                      <li key={idx} className="text-gray-400 text-sm flex items-start gap-2">
                        <span className="text-purple-400 mt-1">•</span>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-light mb-6">
                LET'S WORK
                <br />
                TOGETHER
              </h2>
              <p className="text-gray-400 text-lg mb-8">
                Interested in collaborating on AI/ML projects or full-stack development? Let's connect and build
                something amazing together.
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <Mail className="w-5 h-5 text-purple-400" />
                  <a href="mailto:sharmamuskanofficial@gmail.com" className="hover:text-purple-400 transition-colors">
                    sharmamuskanofficial@gmail.com
                  </a>
                </div>
                <div className="flex items-center gap-4">
                  <Phone className="w-5 h-5 text-purple-400" />
                  <span>+91-9464612885</span>
                </div>
                <div className="flex items-center gap-4">
                  <Linkedin className="w-5 h-5 text-purple-400" />
                  <a
                    href="https://www.linkedin.com/in/muskansharma02"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-purple-400 transition-colors"
                  >
                    LinkedIn Profile
                  </a>
                </div>
                <div className="flex items-center gap-4">
                  <Github className="w-5 h-5 text-purple-400" />
                  <a
                    href="https://github.com/muskanshar"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-purple-400 transition-colors"
                  >
                    GitHub Profile
                  </a>
                </div>
              </div>
            </div>
            <div className="bg-gray-900 p-8 rounded-lg border border-gray-800">
              <h3 className="text-xl font-semibold mb-6">Send a Message</h3>
              <form className="space-y-4">
                <div>
                  <input
                    type="text"
                    placeholder="Your Name"
                    className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg focus:border-purple-400 focus:outline-none"
                  />
                </div>
                <div>
                  <input
                    type="email"
                    placeholder="Your Email"
                    className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg focus:border-purple-400 focus:outline-none"
                  />
                </div>
                <div>
                  <textarea
                    placeholder="Your Message"
                    rows={4}
                    className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg focus:border-purple-400 focus:outline-none resize-none"
                  ></textarea>
                </div>
                <Button className="w-full bg-purple-600 hover:bg-purple-700">Send Message</Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 border-t border-gray-800">
        <div className="max-w-6xl mx-auto text-center text-gray-400">
          <p>&copy; 2025 Muskan Sharma. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
